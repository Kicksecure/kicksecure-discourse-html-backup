article[data-user-id="-2"] div.cooked iframe{border:0}
/*# sourceMappingURL=discourse-narrative-bot_fcb1bbdbaf20ccd5630487986874533dc27a4bfa.css.map?__ws=forums.kicksecure.com */
