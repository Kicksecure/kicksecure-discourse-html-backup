.vote-count-wrapper{font-size:var(--font-up-2);height:40px}
/*# sourceMappingURL=discourse-topic-voting_desktop_fcb1bbdbaf20ccd5630487986874533dc27a4bfa.css.map?__ws=forums.kicksecure.com */
