.vote-count-wrapper{font-size:var(--font-up-2);height:40px}
/*# sourceMappingURL=discourse-topic-voting_desktop_38444776255f14470443461f6df0a5b22686426b.css.map?__ws=forums.kicksecure.com */