article[data-user-id="-2"] div.cooked iframe{border:0}
/*# sourceMappingURL=discourse-narrative-bot_38444776255f14470443461f6df0a5b22686426b.css.map?__ws=forums.kicksecure.com */